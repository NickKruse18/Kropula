CoMoment = function(X,d1,d2){
  return(cor((X[,1]-0.5)^d1,(X[,2]-0.5)^d2))
}


GetMoments = function(par,M,Sim){
  p = length(par)/2;  m = length(M)/2
  A = numeric(10^p*m);  b = numeric(10*p);  n = rep(2,p)
  b[(0:(2*p-1))%%2+10*((0:(2*p-1))%/%10)+1] = par
  Ind = numeric(0)
  for(i in 1:(p^2)){
    for(j in 1:p){
      1
    }
    Sim()
  }
}

FitMoments = function(par,M){

}
