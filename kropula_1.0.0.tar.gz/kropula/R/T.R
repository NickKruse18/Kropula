TOpt = function(A,m){
  if(A[1]<0){ return(Inf) };  if(abs(A[2])>1){ return(Inf) }
  set.seed(2)
  X = TSim(100000,A[1],A[2])
  M = c(CoMoment(X,1,1),CoMoment(X,3,3))
  return(sum((M-m)^2))
}

TFit = function(X){
  m = c(CoMoment(X,1,1),CoMoment(X,3,3))
  W = optim(c(1,0),TOpt,method="BFGS",control=list(reltol=1e-3),m=m)
  nu = W$par[1];  rho = W$par[2]
  p = PairIndependenceTest(cbind(X[,1],TTrn(X[,2],X[,1],nu,rho)))
  return(c(nu,rho,p))
}

TTrn = function(X,Y,nu,rho){
  Y = qt(Y,nu);  Y = (qt(X,nu)-rho*Y)/sqrt((nu+Y^2)/(nu+1)*(1-rho^2))
  return(pt(Y,nu+1))
}

TSim = function(X=1,nu,rho){
  if(length(X)==1){ X = matrix(c(rt(X,nu),rt(X,nu+1)),X,2) }
  else{ X[,1] = qt(X[,1],nu);  X[,2] = qt(X[,2],nu+1) }
  X[,2] = rho*X[,1] + sqrt((nu+X[,1]^2)/(nu+1)*(1-rho^2))*X[,2]
  return(pt(X,nu))
}

