ExpOpt = function(A,m){
  if(A[1]<0){ return(Inf) };  if(A[1]>0.85){ return(Inf) }
  set.seed(2)
  X = ExpSim(100000,A[1])
  M = c(CoMoment(X,1,1))
  return(sum((M-m)^2))
}

ExpFit = function(X){
  m = c(CoMoment(X,1,1))
  W = optim(c(0.4),ExpOpt,method="BFGS",control=list(reltol=1e-3),m=m)
  rho = W$par[1]
  p = PairIndependenceTest(cbind(X[,1],ExpTrn(X[,2],X[,1],rho)))
  return(c(rho,p))
}

ExpTrn = function(X,Y,rho){
  return(pgamma(qexp(X)-qgamma(Y,rho),1-rho))
}

ExpSim = function(X=1,rho){
  if(length(X)==1){ X = matrix(cbind(runif(X),rgamma(X,1-rho)),X,2) }
  else{ X[,2] = qgamma(X[,2],1-rho) }
  X[,2] = pexp(qgamma(X[,1],rho) + X[,2])
  return(X)
}

