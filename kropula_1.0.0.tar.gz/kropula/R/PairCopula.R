PairCopulaFit = function(X,m=100,b=0.02,p=0.95,den=F){
  n = nrow(X)
  if(PairIndependenceTest(X,p)){ return(list("I")) }
  else{
    C = GausFit(X)
    if(C[2]==1){ return(list("Gauss",C[1])) }
    #C = TFit(X)
    #if(C[3]==1){ return(list("T",C[1],C[2])) }
    C = NonParametricFit(X,m=m,b=b)
  }
  return(list("NP",C))
}

PairCopulaTrn = function(X,Y,C){
  if(C[[1]] == "I"){ return(X) }
  else if(C[[1]] == "Gauss"){ return(GausTrn(X,Y,C[[2]])) }
  else if(C[[1]] == "T"){ return(TTrn(X,Y,C[[2]],C[[3]])) }
  else if(C[[1]] == "NP"){ return(NonParametricTrn(X,Y,C[[2]])) }
  return(X)
}

PairCopulaSim = function(X=0,C){
  if(length(X)==1){ X = matrix(runif(2*X),X,2) }
  if(C[[1]] == "I"){ return(X) }
  else if(C[[1]] == "Gauss"){ return(GausSim(X,C[[2]])) }
  else if(C[[1]] == "T"){ return(TSim(X,C[[2]],C[[3]])) }
  else if(C[[1]] == "NP"){ return(NonParametricSim(X,C[[2]])) }
  return(X)
}










