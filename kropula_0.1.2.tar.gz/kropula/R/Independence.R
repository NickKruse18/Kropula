PairIndependenceTest = function(X,p){
  n = length(X[,1]);  C = matrix(0,10,10)
  U = ceiling(10*UnifySample(X))
  u1 = U[,1];  u2 = U[,2]
  for(i1 in 1:10){
    for(i2 in 1:10){
      C[i1,i2] = sum((u1==i1)&(u2==i2))/n
    }
  }
  con = c(qbinom(1-p^(1/100),round(n/10),0.1),qbinom(p^(1/100),round(n/10),0.1))/n
  test = c(min(C),max(C))
  return((test[1]>con[1])&(test[2]<con[2]))
}
