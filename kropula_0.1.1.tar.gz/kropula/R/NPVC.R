NPVC = function(Data,ar=0,m=100,b=0.02){
  d = length(Data[1,])
  D = Marginals(Data);  ID = MarginalsInverted(Data)
  A.U = UnifySample(Data)
  V = VineEstimator(d*(1+ar));  VS = VineSimulator(V)
  VC = CopulaVineAutoRegressive(A.U,V,ar,m=m,b=b)
  return(list(Marginals = D, InverseMarginals = ID, Vine = V, VineSimulator = VS,
              VineCopula = VC, ar = ar))
}

NPVCSample = function(n,steps,NPVC,vals=NULL){
  if(is.null(vals)){ vals = matrix(runif(n),n,1) }
  if(!is.matrix(vals)){ vals = rep(1,n)%*%t(vals) }
  ID = NPVC$InverseMarginals;  ar = NPVC$ar;  d = length(ID[1,])/2
  V = NPVC$Vine;  VS = NPVC$VineSimulator;  VC = NPVC$VineCopula
  dist = matrix(0,n,d*(ar+steps));  dist[,1:(d*(1+ar))] = CopulaVinePredict(n,vals,V,VS,VC,d*(1+ar))
  for(i in 2:steps){ if(steps==1){ break }
    if(ar==0){
      dist[,1:d+d*(i-1)] = CopulaVinePredict(n,matrix(runif(n),n,1),V,VS,VC,d)
    }
    else{
      dist[,1:d+d*(ar+i-1)] = CopulaVinePredict(n,dist[,1:(d*ar)+d*(i-1)],V,VS,VC,d*(1+ar))
    }
  }
  for(i in 1:(ar+steps)){
    dist[,1:d+d*(ar+i-1)] = MarginalsFromUniform(dist[,1:d+d*(ar+i-1)],ID)
  }
  return(dist)
}
