CopulaVineEstimate = function(X,V,m=100,b=0.02){
  VC = list();  C = matrix(0,m,m)
  for(i in 1:length(V[,1])){
    I = V[i,]
    if(I[1] == 0){
      if(!PairIndependenceTest(X[,c(I[2],I[3])])){
        C = PairCopula(X[,c(I[2],I[3])],m=m,b=b);  VC = append(VC,list(C))
      }
      else{
        C[1:(m^2)] = 0;  VC = append(VC,list("I"))
      }
    }
    if(I[1] == 1){
      if(C[m^2]!=0){ X[,I[2]] = PairCopulaTransform(X[,I[2]],X[,I[3]],C) }
    }
  }
  return(VC)
}

CopulaVineSimulate = function(n,V,VS,VC,d){
  X = U = matrix(runif(d*n),n,d)
  for(i in 1:length(VS[,1])){
    if(!is.matrix(VC[[VS[i,2]]])){ next }
    X[,V[VS[i,3],3]] = PairCopulaSimulate(n,VC[[VS[i,4]]],cbind(U[,V[VS[i,3],2]],X[,V[VS[i,3],3]]))[,2]
  }
  return(X)
}

CopulaVinePredict = function(n,vals,V,VS,VC,d){
  k = length(vals[1,]);  X = U = cbind(vals,matrix(runif((d-k)*n),n,d-k))
  if(k > 1){
    for(i in 1:(k*(k-1)/2)){
      if(!is.matrix(VC[[VS[i,2]]])){ next }
      U[,V[VS[i,1],3]] = PairCopulaTransform(U[,V[VS[i,1],3]],U[,V[VS[i,1],2]],VC[[VS[i,2]]])
    }
  }
  for(i in (k*(k-1)/2+1):length(VS[,1])){
    if(!is.matrix(VC[[VS[i,2]]])){ next }
    X[,V[VS[i,3],3]] = PairCopulaSimulate(n,VC[[VS[i,4]]],cbind(U[,V[VS[i,3],2]],X[,V[VS[i,3],3]]))[,2]
  }
  return(X)
}

CopulaVineAutoRegressive = function(Data,V,ar=0,m=100,b=0.02){
  d = length(Data[1,]);  n = length(Data[,1])-ar
  X = matrix(0,n,d*(1+ar))
  for(j in ar:0){ X[,1:d+d*(ar-j)] = Data[1:n+ar-j,] }
  VC = CopulaVineEstimate(X,V,m=m,b=b)
  return(VC)
}
