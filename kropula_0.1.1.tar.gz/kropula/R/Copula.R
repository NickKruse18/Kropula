
PairCopula = function(X,m=100,b=0.02){
  n = length(X[,1]);  C = matrix(0.001,m,m);  b = b*m
  for(i in 1:n){
    x = max((round(m*X[i,1])-b),1):min((round(m*X[i,1])+b),m);  y = max((round(m*X[i,2])-b),1):min((round(m*X[i,2])+b),m)
    C[x,y] = C[x,y] + 1
  }
  C[b:1,] = C[b:1,]*((1:b)%*%t(rep(1,m))+b+1)/(b+1);  C[(m-b+1):m,] = C[(m-b+1):m,]*((1:b)%*%t(rep(1,m))+b+1)/(b+1)
  C[,b:1] = C[,b:1]*(rep(1,m)%*%t(1:b)+b+1)/(b+1);  C[,(m-b+1):m] = C[,(m-b+1):m]*(rep(1,m)%*%t(1:b)+b+1)/(b+1)
  for(i in 1:m){ C[,i] = cumsum(C[,i]) }
  for(i in 1:m){ C[i,] = cumsum(C[i,]) }

  C = C*C[m,m]*((1:m)/C[,m]/m)%*%t((1:m)/C[m,]/m)
  return(C)
}


PairCopulaTransform = function(X,Y,C){
  X[X>0.9999] = 0.9999;  Y[Y>0.9999] = 0.9999#;  X[X<0.000001] = 0.001;  Y[Y<0.000001] = 0.001
  m = length(C[,1]);  n = length(X);  X.T = numeric(n)
  X.I = floor(m*X)+1;  Y.I = floor(m*Y)+1
  dC = (C-rbind(0,C[1:(length(C[1,])-1),]));  dC = cbind(0,dC/(dC[,m]%*%t(rep(1,m))))
  dC[dC<=0] = 0.0001
  Ind = m*X.I + Y.I - m
  X.T = (X.I-m*X)*dC[Ind] + (1+m*X-X.I)*dC[Ind+m]
  X.T[X.T>0.9999] = 0.9999
  return(X.T)
}

PairCopulaInvert = function(C){
  m = length(C[,1]);  dC = (C-rbind(0,C[1:(length(C[1,])-1),]));  dC = cbind(0,dC/(dC[,m]%*%t(rep(1,m))))
  dCInv = matrix(0,m,m)
  for(i1 in 1:m){
    I = 1;  i2 = 1
    while(i2 <= m){
      if(dC[i1,1+I] < i2/m){ I = I + 1;  next }
      t = (i2/m-dC[i1,I])/(dC[i1,1+I]-dC[i1,I])
      dCInv[i1,i2] = t + I - 1;  i2 = i2 + 1
    }
  }
  return(cbind(0,dCInv))
}

PairCopulaSimulate = function(n,C,X=0){
  m = length(C[,1]);  dCInv = PairCopulaInvert(C)
  if(length(X)==1){ X = matrix(runif(2*n),n,2) }
  U = floor(m*X[,2]+1);  Ind = m*U + floor(m*X[,1]+1) - m
  X[,2] = ((U-m*X[,2])*dCInv[Ind] + (1+m*X[,2]-U)*dCInv[Ind+m])/m
  return(X)
}

PairCopulaShow = function(X,show,ar=c(),m=100,b=0.02){
  n = length(X[,1]);  X = UnifySample(X);  s = length(show)/2
  par(mfrow=c(ceiling(sqrt(s)),2*floor(sqrt(s))));  par(mar = c(4.6, 4.1, 1.6, 0.6))
  for(i in 1:s){
    C = PairCopula(X[,c(show[2*i-1],show[2*i])],m=m,b=b)
    C = C-cbind(0,C[,-m]);  C = C-rbind(0,C[-m,])
    plot(X[,c(show[2*i-1],show[2*i])],cex=0.5)
    image(C,col = hcl.colors(100, "terrain"))
    print(sum((C-0.0001)^2))
  }
  par(mfrow=c(1,1));  par(mar = c(5.1, 4.1, 4.1, 2.1))
}

