









Poly = function(a,x1,y1,x2,y2,X){
  n = nrow(X)
  P = a*matrix(c(1,-1,-1,1),2,2)
  dX = c(x1,x2)*P
  for(i in 1:n){
    X[i,2] = uniroot(function(x){return(x+(X[i,1]^c(x1-1,x2-1)%*%dX)%*%x^c(y1,y2)-X[i,2]) },c(0,1))$root
  }
  plot(X)
  print(cor(X[,1],X[,2]))
  print(sum(X[,1]*X[,2])/n)
  hist(X[,2])
  return(X)
}

Poly(1,1,1,2,2,Poly(1,1,1,2,2,matrix(runif(20000),10000,2)))


PolyMax = function(a,k){
  x = (a*(a-1)/(a+k)/(a+k-1))^(1/k)
  return(a*x^(a-1) - (a+k)*x^(a+k-1))
}

PolyMax(10,10)

PolyMoment = function(ax,ay,kx,ky,nx,ny){
  fx = PolyMax(ax,kx);  fy = PolyMax(ay,ky)
  int = c(1/min(-ky*fx,-kx*fy), 1/max(fx*fy,kx*ky))
  Moment = (ax/(ax+nx) - (ax+kx)/(ax+nx+kx))*(ay/(ay+ny) - (ay+ky)/(ay+ny+ky))
  Mint = 1/(1+nx)/(1+ny)+Moment*int
  print(int)
  return(Mint)
}

PolyMoment(2,1,1,4,1,1)






































