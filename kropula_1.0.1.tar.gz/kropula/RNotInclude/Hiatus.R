

Vine = function(){
  d = as.integer(readline("Dimensions: "))
  A = matrix(F,d,d);  diag(A) = T;  W = T;  V = list()
  while(W){
    a = readline("Specify edge: ")
    if(a=="W"){ break }
    b1 = NA
    try({
      a = gsub(' ', '', a);
      b = strsplit(a,',')[[1]];  b = as.integer(b)
    },silent=TRUE)
    if(is.na(b[1])){ print("Invalid input. Must be on a form like:  1,3.");  next }
    if(length(b)<2){ print("set must have more than one element.");  next }
    if(max(b)>d){ print("Values must be less than or equal to the dimensions.");  next }
    C = A[,b[1]]&A[,b[2]];  D = xor(A[,b[1]],A[,b[2]]);  f = F
    for(i in 3:length(b)){
      if(length(b)<i){ break }
      print(A[,b[i]])
      C = C&A[,b[i]];  if(sum(D&A[,b[i]])>0){ f = T;  break };  D = xor(D,A[,b[i]])
    };  print(cbind(C,D));  if(sum(D)>length(b)){ f = T};  if(f){ print("Impossible connection");  next }

    for(i2 in 2:length(b)){ for(i1 in 1:(i2-1)){
      A[c(b[i1],b[i2]),c(b[i2],b[i1])] = T
    } }
    print(A)
    a = readline("Specify Copula for the Edge: ")
    #V = append(V,list(list(b1),list(b2),a))
    if(a=="W"){ break }
  }
}















