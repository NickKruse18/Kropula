











Y = rmvn(10000,rep(0,3),matrix(c(1,0.5,0.8,0.5,1,0.7,0.8,0.7,1),3,3))

Y[sample(30000,3000)] = NA

plot(NPVCFill(Y)[,1:2])

X = rmvn(100,rep(0,3),matrix(c(1,0.5,0.8,0.5,1,0.7,0.8,0.7,1),3,3))

VC = NPVC(X)

cor(NPVCSample(10000,1,VC))


image(VC$VineCopula[[3]][[2]])

GausFit(GausSim(1000,0.5))













