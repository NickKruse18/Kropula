PairCopulaNormalize = function(C){
  n = nrow(C);  C = C1 = C2 = C[1:n^2]
  for(i in 1:n){
    C1[i*n+1:n-n] = sum(C1[i*n+1:n-n])
    C2[n*(1:n)-n+i] = sum(C2[n*(1:n)-n+i])
  }
  D = C-(C1+C2-sum(C)/n)/n
  D = D - min(D,0)
  D2 = matrix(D,n,n)
  return(D2)
}

PairCopula = function(X,m=100,b=0.02,den=F){
  n = nrow(X);  C = matrix(0,m,m);  b = b*m
  for(i in 1:n){
    x = max((round(m*X[i,1])-b),1):min((round(m*X[i,1])+b),m);  y = max((round(m*X[i,2])-b),1):min((round(m*X[i,2])+b),m)
    C[x,y] = C[x,y] + 1
  }
  C[b:1,] = C[b:1,]*((1:b)%*%t(rep(1,m))+b+1)/(b+1);  C[(m-b+1):m,] = C[(m-b+1):m,]*((1:b)%*%t(rep(1,m))+b+1)/(b+1)
  C[,b:1] = C[,b:1]*(rep(1,m)%*%t(1:b)+b+1)/(b+1);  C[,(m-b+1):m] = C[,(m-b+1):m]*(rep(1,m)%*%t(1:b)+b+1)/(b+1)
  C = C/rowSums(C)
  C = PairCopulaNormalize(C)
  if(den){ return(C/sum(C)) }
  for(i in 1:m){ C[,i] = cumsum(C[,i]) }
  for(i in 1:m){ C[i,] = cumsum(C[i,]) }
  return(C/C[m,m])
}
