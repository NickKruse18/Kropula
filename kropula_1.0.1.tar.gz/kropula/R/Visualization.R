
PairCopulaShow = function(X,show,ar=c(),m=100,b=0.02){
  n = nrow(X);  X = UnifySample(X);  s = length(show)/2
  par(mfrow=c(ceiling(sqrt(s)),2*floor(sqrt(s))));  par(mar = c(4.6, 4.1, 1.6, 0.6))
  for(i in 1:s){
    C = PairCopula(X[,c(show[2*i-1],show[2*i])],m=m,b=b)
    C = C-cbind(0,C[,-m]);  C = C-rbind(0,C[-m,])
    plot(X[,c(show[2*i-1],show[2*i])],cex=0.5)
    image(C,col = hcl.colors(100, "terrain"))
    print(sum((C-0.0001)^2))
  }
  par(mfrow=c(1,1));  par(mar = c(5.1, 4.1, 4.1, 2.1))
}

