CopulaVineEstimate = function(X,V,m=100,b=0.02,p=0.95){
  VC = list();  C = matrix(0,m,m)
  for(i in 1:nrow(V)){
    I = V[i,]
    if(I[1] == 0){
      C = PairCopulaFit(X[,c(I[2],I[3])],m=m,b=b,p=p)
      VC = append(VC,list(C))
    }
    if(I[1] == 1){
      X[,I[2]] = PairCopulaTrn(X[,I[2]],X[,I[3]],C)
    }
  }
  return(VC)
}

CopulaVineSimulate = function(n,V,VS,VC,d){
  X = U = matrix(runif(d*n),n,d)
  for(i in 1:nrow(VS)){
    X[,V[VS[i,3],3]] = PairCopulaSim(cbind(U[,V[VS[i,3],2]],X[,V[VS[i,3],3]]),VC[[VS[i,4]]])[,2]
  }
  return(X)
}

CopulaVinePredict = function(n,vals,V,VS,VC,d){
  k = ncol(vals);  X = U = cbind(vals,matrix(runif((d-k)*n),n,d-k))
  if(k > 1){
    for(i in 1:(k*(k-1)/2)){
      U[,V[VS[i,1],3]] = PairCopulaTrn(U[,V[VS[i,1],3]],U[,V[VS[i,1],2]],VC[[VS[i,2]]])
    }
  }
  for(i in (k*(k-1)/2+1):nrow(VS)){
    X[,V[VS[i,3],3]] = PairCopulaSim(cbind(U[,V[VS[i,3],2]],X[,V[VS[i,3],3]]),VC[[VS[i,4]]])[,2]
  }
  return(X)
}

CopulaVineAutoRegressive = function(Data,V,ar=0,m=100,b=0.02,p=0.95){
  d = ncol(Data);  n = nrow(Data)-ar
  X = matrix(0,n,d*(1+ar))
  for(j in ar:0){ X[,1:d+d*(ar-j)] = Data[1:n+ar-j,] }
  VC = CopulaVineEstimate(X,V,m=m,b=round(0.126/n^(1/5),2),p=p)
  return(VC)
}
