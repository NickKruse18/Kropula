LinearSimplify = function(x,m=1000){
  x = sort(x);  C = matrix(0,m+1,2);  C[,1] = (0:m)/(m+0.0001)*(x[length(x)]-x[1])+x[1];  j = 2;  i = 1
  while(i <= nrow(C)){
    if(C[i,1] > x[j]){ j = j + 1;  next; }
    C[i,2] = ((C[i,1]+10^(-5)*x[j]-x[j-1])/((1+10^(-5))*x[j]-x[j-1]) + j-1)/length(x)
    i = i + 1
  }
  return(C)
}

LinearSimplifyInverted = function(x,m=1000){
  y = 1:length(x);  y = (y-y[1]) / (y[length(y)]-y[1])
  C = matrix(0,m+1,2);  C[,1] = (0:m)/m;  i = 0;  j = 2
  while(j <= length(y)){
    if(i/m-0.0000001 >= y[j]){ j = j + 1;  next; }
    C[i+1,2] = (i/m-y[j-1])*(x[j]-x[j-1])/(y[j]-y[j-1]) + x[j-1]
    i = i + 1
  }
  return(C[,2])
}

Marginals = function(X,m=1000){
  d = ncol(X);  D = matrix(0,m+1,2*d)
  for(i in 1:d){
    D[,(2*i-1):(2*i)] = LinearSimplify(X[!is.na(X[,i]),i],m)
  }
  return(D)
}

MarginalsInverted = function(X,m=1000){
  d = ncol(X);  D = matrix(0,m+1,d)
  for(i in 1:d){
    D[,i] = LinearSimplifyInverted(sort(X[!is.na(X[,i]),i]),m)
  }
  return(D)
}

MarginalsFromUniform = function(U,D){
  d = ncol(U);  m = nrow(D)-1;  M = U;  U = m*U+1;  U.I = floor(U)
  for(i in 1:d){
    M[,i] = (U[,i]-U.I[,i])*D[U.I[,i],i] + (1-U[,i]+U.I[,i])*D[U.I[,i]+1,i]
  }
  return(M)
}

MarginalsToUniform = function(X,D){
  d = ncol(X);  m = nrow(D)-1;  M = X;  X = m*t((t(X)-D[1,2*(1:d)-1])/(D[m,2*(1:d)-1]-D[1,2*(1:d)-1]))+1
  X = pmax(pmin(X, 1000), 1);  X.I = floor(X)
  for(i in 1:d){
    M[,i] = (X[,i]-X.I[,i])*D[X.I[,i],2*i] + (1-X[,i]+X.I[,i])*D[X.I[,i]+1,2*i]
  }
  return(M)
}

UnifySample = function(X){
  for(i in 1:ncol(X)){
    X[,i] = (match(X[,i],sort(X[,i]))-0.5)/sum(!is.na(X[,i]))
  }
  return(X)
}

