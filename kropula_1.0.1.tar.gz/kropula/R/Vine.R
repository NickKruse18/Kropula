VineEstimator = function(d,type="C"){
  V = matrix(0,0,3)
  if(type=="C"){
    for(i in 1:(d-1)){
      for(j in (i+1):d){
        V = rbind(V,c(0,i,j))
        if(i<d-1){ V = rbind(V,c(1,j,i)) }
      }
    }
  }
  return(V)
}

VineSimulator = function(V){
  d = max(V[,-1]);  VS = matrix(0,d*(d-1)/2,4)
  I1 = numeric(d^2);  i3 = 0
  for(i2 in 2:d){ for(i1 in 1:(i2-1)){ i3 = i3 + 1;  I1[i1+d*i2-d] = i3 } }
  I2 = numeric(d^2);  i3 = 0
  for(i2 in 2:d){ for(i1 in (i2-1):1){ i3 = i3 + 1;  I2[i1+d*i2-d] = i3 } }
  i2 = 0
  for(i1 in 1:length(V[,1])){
    if(V[i1,1]==1){ next }
    i2 = i2 + 1
    VS[I1[V[i1,2]+d*V[i1,3]-d],1] = VS[I2[V[i1,2]+d*V[i1,3]-d],3] = i1
    VS[I1[V[i1,2]+d*V[i1,3]-d],2] = VS[I2[V[i1,2]+d*V[i1,3]-d],4] = i2
  }
  return(VS)
}
