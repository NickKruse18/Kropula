GausFit = function(X){
  rho = cor(qnorm(X[,1]),qnorm(X[,2]))
  p = PairIndependenceTest(cbind(X[,1],GausTrn(X[,2],X[,1],rho)))
  return(c(rho,p))
}

GausTrn = function(X,Y,rho){
  return(pnorm((qnorm(X)-rho*qnorm(Y))/sqrt(1-rho^2)))
}

GausSim = function(X=1,rho){
  if(length(X)==1){ X = matrix(rnorm(2*X),X,2) }
  else{ X = qnorm(X) }
  X[,2] = rho*X[,1] + sqrt(1-rho^2)*X[,2]
  return(pnorm(X))
}


