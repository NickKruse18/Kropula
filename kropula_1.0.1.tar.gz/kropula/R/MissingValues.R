NPVCFill = function(Data){
  Ind = !is.na(Data);  d = ncol(Data);  n = nrow(Data)
  ID = MarginalsInverted(Data);  X = UnifySample(Data)
  for(i1 in 1:d){
    Xm = rbind(0,matrix(1/100,100,n))
    for(i2 in 1:d){
      if(i1==i2){ next }
      Inds = Ind[,i1]&Ind[,i2]
      C = NonParametricFit(X[Inds,c(i1,i2)],den=T)
      Inds = (!Ind[,i1])&Ind[,i2]
      Xm[2:101,Inds] = Xm[2:101,Inds] * (C[,1+floor(100*X[Inds,i2])])
    }
    U = 100*runif(n)
    for(i in 1:n){
      if(Ind[i,i1]){ next }
      Xm[,i] = cumsum(Xm[,i])/sum(Xm[,i])
      I = 1;  i2 = 1
      while(i2 <= ceiling(U[i])){
        if(Xm[1+I,i] < (i2-1)/100){ I = I + 1;  next }
        i2 = i2 + 1
      }
      while(Xm[1+I,i] < (i2-1)/100){ I = I + 1;  next }
      t = ((i2-1)/100-Xm[I,i])/(Xm[1+I,i]-Xm[I,i])
      if(t+I-1>100){ print(c(t,I,i2/100,Xm[I,i],Xm[1+I,i])) }
      U[i] = t + I - 1
    }
    X[!Ind[,i1],i1] = U[!Ind[,i1]]/100.1
  }
  return(MarginalsFromUniform(X,ID))
}
