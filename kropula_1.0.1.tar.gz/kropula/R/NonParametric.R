NonParametricFit = function(X,m=100,b=0.02,den=F){
  n = nrow(X);  C = matrix(0,m,m);  b = b*m
  for(i in 1:n){
    x = max((round(m*X[i,1])-b),1):min((round(m*X[i,1])+b),m);  y = max((round(m*X[i,2])-b),1):min((round(m*X[i,2])+b),m)
    C[x,y] = C[x,y] + 1
  }
  C[b:1,] = C[b:1,]*((1:b)%*%t(rep(1,m))+b+1)/(b+1);  C[(m-b+1):m,] = C[(m-b+1):m,]*((1:b)%*%t(rep(1,m))+b+1)/(b+1)
  C[,b:1] = C[,b:1]*(rep(1,m)%*%t(1:b)+b+1)/(b+1);  C[,(m-b+1):m] = C[,(m-b+1):m]*(rep(1,m)%*%t(1:b)+b+1)/(b+1)

  if(den){ return(C/sum(C)) }
  for(i in 1:m){ C[,i] = cumsum(C[,i]) }
  for(i in 1:m){ C[i,] = cumsum(C[i,]) }
  return(C/C[m,m])
}

NonParametricTrn = function(X,Y,C){
  m = nrow(C);  n = length(X);  X.T = numeric(n)
  X.I = floor(m*X)+1;  Y.I = floor(m*Y)+1
  dC = (C-rbind(0,C[1:(m-1),]));  dC = cbind(0,dC/(dC[,m]%*%t(rep(1,m))))
  Ind = m*X.I + Y.I - m
  X.T = (X.I-m*X)*dC[Ind] + (1+m*X-X.I)*dC[Ind+m]
  return(X.T)
}

NonParametricInvert = function(C){
  m = nrow(C);  dC = (C-rbind(0,C[1:(m-1),]));  dC = cbind(0,dC/(dC[,m]%*%t(rep(1,m))))
  dCInv = matrix(0,m,m)
  for(i1 in 1:m){
    I = 1;  i2 = 1
    while(i2 <= m){
      if(dC[i1,1+I] < i2/m){ I = I + 1;  next }
      t = (i2/m-dC[i1,I])/(dC[i1,1+I]-dC[i1,I])
      dCInv[i1,i2] = t + I - 1;  i2 = i2 + 1
    }
  }
  return(cbind(0,dCInv))
}

NonParametricSim = function(X=0,C){
  m = nrow(C);  dCInv = NonParametricInvert(C)
  if(length(X)==1){ X = matrix(runif(2*X),X,2) }
  U = floor(m*X[,2]+1);  Ind = m*U + floor(m*X[,1]+1) - m
  X[,2] = ((U-m*X[,2])*dCInv[Ind] + (1+m*X[,2]-U)*dCInv[Ind+m])/m
  return(X)
}
