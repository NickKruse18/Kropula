Kro.NPVCCopula = function(Data,ar=0,sort=c(),m=100,b=0.02){
  d = length(Data[1,]);  n = length(Data[,1])-ar
  if(length(sort)==0){ sort = 1:d };  d = length(sort)
  X = matrix(0,n,d*(1+ar))
  for(j in ar:0){ X[,1:d+d*(ar-j)] = Data[1:n+ar-j,sort] }
  VC = Kro.CopulaVineEstimate(X,m=m,b=b)
  return(VC)
}

Kro.NPVC = function(Data,ar=0,sort=c(),m=100,b=0.02){
  d = length(Data[1,])
  if(length(sort)==0){ sort = 1:d };  d = length(sort)
  D = Kro.Marginals(Data[,sort,drop=F])
  ID = Kro.MarginalsInverted(Data[,sort,drop=F])
  A.U = Kro.UnifySample(Data[,sort,drop=F])
  VC = Kro.NPVCCopula(A.U,ar,sort,m=m,b=b)
  return(list(Marginals = D, InverseMarginals = ID,
              VineCopula = VC, m = m, ar = ar, sort = sort))
}

Kro.NPVCSample = function(n,steps,NPVC,vals=NULL){
  if(is.null(vals)){ vals = matrix(runif(n),n,1) }
  if(!is.matrix(vals)){ vals = rep(1,n)%*%t(vals) }
  ID = NPVC[[2]];  VC = NPVC[[3]];  m = NPVC[[4]];  ar = NPVC[[5]];  d = length(ID[1,])/2
  dist = matrix(0,n,d*(ar+steps));  dist[,1:(d*(1+ar))] = Kro.CopulaVinePredict(n,vals,VC,m)
  for(i in 2:steps){ if(steps==1){ break }
    dist[,1:d+d*(ar+i-1)] = Kro.CopulaVinePredict(n,dist[,1:(d*ar)+d*(i-1)],VC,m)
  }
  for(i in 1:(ar+steps)){
    dist[,1:d+d*(ar+i-1)] = Kro.MarginalsFromUniform(dist[,1:d+d*(ar+i-1)],ID)
  }
  return(dist)
}

